import csv
import os
import sys
import time
from glob import glob
from math import ceil

from scrapy.utils.project import get_project_settings
from scrapy.crawler import CrawlerProcess
from spiders.skiptrace_names import SkipTracingNamesSpider
import multiprocessing
from functools import partial

input_master_filename = 'input/input master file.csv'


def run_spider(search_rows, inputs):
    process = CrawlerProcess(get_project_settings())
    process.crawl(SkipTracingNamesSpider, search_rows=search_rows, user_inputs=inputs)
    process.start()


def make_input_master_file():
    input_files = glob('input/*.csv')

    # if len(input_files) > 1:
    #     # remove master file if it exists and if there are other files exists too.
    #     if os.path.isfile(input_master_filename):
    #         os.remove(input_master_filename)

    input_data = []

    for filename in input_files:
        with open(filename, mode='r', encoding='utf8') as input_file:
            input_data.extend(list(csv.DictReader(input_file)))

        # delete input files after merging into master file
        os.remove(filename)

    write_input_master_file(input_data)


def write_input_master_file(rows):
    input_csv_fieldnames = [
        'Address', 'City', 'State', 'Zip',

        'Owner 1 First Name', 'Owner 1 Last Name',
        'Owner 2 First Name', 'Owner 2 Last Name',

        'Owner Mailing Address', 'Owner Mailing City', 'Owner Mailing State', 'Owner Mailing Zip'
    ]

    with open(input_master_filename, mode='a', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)

        if csvfile.tell() == 0:
            writer.writerow(input_csv_fieldnames)

        for row in rows:
            writer.writerow([row.get(col) or row.get(col.replace('Owner ', '')) for col in input_csv_fieldnames])


def read_input_csv_file():
    # First merge all the existing input files into one file and remove unwanted columns
    make_input_master_file()

    try:
        with open(input_master_filename, mode='r', encoding='utf8') as input_file:
            return list(csv.DictReader(input_file))
    except IndexError:
        print('No CSV file found inside the input folder')
    except FileNotFoundError as e:
        print('No CSV file found inside the input folder')

    return []


def get_user_inputs():
    # get user input1 "Get the output filename from user"

    while True:
        user_output_filename = input('\n\nEnter The Output Filename (Example: output.csv): ')

        if not user_output_filename:
            print('Filename should not be empty')
            continue
        else:
            break

    if not user_output_filename.endswith('.csv'):
        user_output_filename = f'{user_output_filename}.csv'

    output_filename = f'output/{user_output_filename}'

    # user input2  "is it urgent scraping required?" (in urgent/fast scraping, we are not filtering the phone1 type)
    print('\nDo you need fast scraping/results? (In Fast scraping, Phone1 will not be filtered as Wireless)')
    is_urgent = input('Enter (y/n): ')

    is_it_urgent = True if 'y' in is_urgent.lower() else False

    # get user input3 "how many items to be scraped"
    items_count_per_thread = 0
    total_records_required = 0

    while True:
        try:
            total_records_required = int(
                input('\nEnter a number how many Records do you want to scrape: '))

            items_count_per_thread = ceil(total_records_required / num_threads)  # Per thread items

            break
        except:
            print(f'Please Enter a number only')
            continue

    return {'output_filename': output_filename, 'is_it_urgent': is_it_urgent,
            'items_count_to_scrape': total_records_required, 'items_count_per_thread': items_count_per_thread}


def get_key_values_from_file():
    with open('input/config.txt', mode='r', encoding='utf-8') as input_file:
        data = {}

        for row in input_file.readlines():
            if not row.strip():
                continue

            try:
                key, value = row.strip().split('==')
                data.setdefault(key.strip(), value.strip())
            except ValueError:
                pass

        return data


def create_output_file(filename):
    with open(filename, mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)

        output_columns = [
            'Address', 'City', 'State', 'Zip',

            'Mailing Address', 'Mailing City', 'Mailing State', 'Mailing Zip',

            'Owner 1 First Name', 'Owner 1 Last Name',

            'Number 1', 'Number 1 Type', 'Number 1 Status',
            'Number 2', 'Number 2 Type', 'Number 2 Status',
            'Number 3', 'Number 3 Type', 'Number 3 Status',

            'Email 1', 'Email 2', 'Email 3', 'Email 4', 'Email 5',
        ]

        writer.writerow(output_columns)


if __name__ == '__main__':
    # get the configs from file
    config = get_key_values_from_file()
    num_threads = int(config.get('NUM_OF_THREADS', 1))

    # Get rows from input folder csv file
    input_rows = read_input_csv_file()

    if not input_rows:
        print('\n\nNo input file found or files are emtpy....!!!!')
        sys.exit()

    user_inputs = get_user_inputs()  # get all the inputs from users like output file name, is_it_urgent, how many items to scraped

    create_output_file(user_inputs.get('output_filename'))  # Create Output CSV file with header row

    # Create chunks (To split the input rows into number of threads)
    chunk_size = len(input_rows) // num_threads
    chunks = [input_rows[i:i + chunk_size] for i in range(0, len(input_rows), chunk_size)]

    print(f'\n\nTotal Input Rows exists in file: {len(input_rows)}')
    print(f'Number of Threads to Run: {num_threads}')
    print(f'Number of Rows each Thread will process: {chunk_size}')
    print(f'Total Results Required to be Scraped: {user_inputs.get("items_count_to_scrape")}')
    print(f'Results each Thread will Scrape: {user_inputs.get("items_count_per_thread")}\n\n')

    time.sleep(5)

    # Process Threads based on the number of chunks
    # Each thread will work independent of each other and they will run in parallel
    with multiprocessing.Pool(num_threads) as pool:
        try:
            # Use functools.partial to create a partial function with fixed output_filename argument
            partial_run_spider = partial(run_spider, inputs=user_inputs)

            # Run the spider in parallel with different parameters (including output_filename)
            pool.map(partial_run_spider, chunks)
        except Exception as e:
            pass
