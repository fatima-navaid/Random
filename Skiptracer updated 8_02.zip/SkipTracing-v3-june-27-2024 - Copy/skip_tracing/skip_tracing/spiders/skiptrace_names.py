import csv
import json
from collections import OrderedDict
from datetime import datetime
from multiprocessing import Lock

from nameparser import HumanName
from scrapy import Spider, Request
from scrapy.exceptions import CloseSpider
from slugify import slugify


def get_key_values_from_file():
    with open('input/config.txt', mode='r', encoding='utf-8') as input_file:
        data = {}

        for row in input_file.readlines():
            if not row.strip():
                continue

            try:
                key, value = row.strip().split('==')
                data.setdefault(key.strip(), value.strip())
            except ValueError:
                pass

        return data


class SkipTracingNamesSpider(Spider):
    name = 'skiptrace_names'
    base_url = 'https://www.cyberbackgroundchecks.com'
    start_urls = [base_url]
    quotes_url = 'https://quotes.toscrape.com'

    config = get_key_values_from_file()
    zyte_key = config.get('ZYTE_KEY')
    zyte_proxy_url = config.get('ZYTE_SMARTPROXY_URL')
    max_concurrency_limit = int(config.get('ZYTE_MAX_CONCURRENCY_ALLOWED', '8'))
    max_num_of_chunks = int(config.get('NUM_OF_THREADS', '5'))
    concurrent_requests = int(max_concurrency_limit / max_num_of_chunks)

    custom_settings = {
        'CONCURRENT_REQUESTS': concurrent_requests,

        'CRAWLERA_ENABLED': True,
        'CRAWLERA_APIKEY': zyte_key,
        'CRAWLERA_URL': zyte_proxy_url,  # Required for Zyte SPM Enterprized account only
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy_crawlera.CrawleraMiddleware': 610,
        }
    }

    headers = {
        'authority': 'www.cyberbackgroundchecks.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'referer': 'https://www.cyberbackgroundchecks.com/address',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    }

    def __init__(self, search_rows=None, user_inputs=None, **kwargs):
        super().__init__(**kwargs)
        self.output_filename = user_inputs.get('output_filename')
        self.is_it_urgent = user_inputs.get(
            'is_it_urgent')  # if script is urgent then we need to get all phone1 type otherwise get only wireless type phone

        self.items_count_to_scrape = user_inputs.get('items_count_per_thread')

        # self.custom_settings['CLOSESPIDER_ITEMCOUNT'] = self.items_count_to_scrape

        self.script_started_at = datetime.now().strftime("%I:%M:%S %p")
        self.item_scraped_counter = 0
        self.other_phone_type_items = []
        self.search_rows = search_rows or []

        # These fields are defined inside the main.py file as well to create the files
        self.output_csv_fieldnames = [
            'Address', 'City', 'State', 'Zip',

            'Mailing Address', 'Mailing City', 'Mailing State', 'Mailing Zip',

            'Owner 1 First Name', 'Owner 1 Last Name',

            'Number 1', 'Number 1 Type', 'Number 1 Status',
            'Number 2', 'Number 2 Type', 'Number 2 Status',
            'Number 3', 'Number 3 Type', 'Number 3 Status',

            'Email 1', 'Email 2', 'Email 3', 'Email 4', 'Email 5',
        ]

        self.csv_mapped_item_fieldnames = self.get_item_fields_names()
        self.multiprocessing_file_lock = Lock()

    def start_requests(self):
        yield Request(url=self.base_url, headers=self.headers)

    def parse(self, response, **kwargs):
        for search_row in self.search_rows:
            search_street = search_row.get('Owner Mailing Address', '').strip()
            search_city = search_row.get('Owner Mailing City', '').strip()
            search_state = search_row.get('Owner Mailing State', '').strip()

            # Without address, city or state, records could not be found
            if not search_street or not search_city or not search_state:
                continue

            url = f'{self.base_url}/address/{slugify(search_street)}/{slugify(search_city)}/{slugify(search_state)}'
            yield Request(url=url, callback=self.find_persons, headers=self.headers,
                          meta={'row': search_row, 'handle_httpstatus_list': [404]}, dont_filter=True)

    def find_persons(self, response):
        try:
            persons_json = {person_item.get('name'): person_item for person_item in
                            json.loads(response.css('script:contains("Person")::text').get(''))}
        except:
            persons_json = {}

        input_row = response.meta.get('row')

        owners_urls = []

        for i in range(1, 3):  # To search and match 2 owners (Owner1 and Owner2) from input file
            for person in response.css('.card.card-hover'):

                if not self.is_person_matched(input_row, person, owner=i, persons_json=persons_json):
                    continue

                owner_url = person.css('.btn-primary.btn-block ::attr(href)').get('')
                if not owner_url:
                    continue

                person_url = response.urljoin(owner_url)
                owners_urls.append({i: person_url})
                break

        # Request on both owners and treat them as 1 owner. If there are 2 owners, there will be 2 items yield required
        for index, owner in enumerate(owners_urls):
            owner_url = owner.get(index + 1)

            try:
                yield Request(url=owner_url, callback=self.parse_person_details, headers=self.headers,
                              meta={'input_row': input_row},
                              dont_filter=True)
            except TypeError:
                pass

    def parse_person_details(self, response):
        input_row = response.meta.get('input_row')

        # owner_num = response.meta.get('owner_num', 1)
        item = OrderedDict()
        item.update(self.get_item_input_fields(input_row))
        item.update(self.get_person_item(response, 1))

        if not item.get('Number 1'):
            return

        if 'wireless' not in item.get('Number 1 Type', '').lower().strip() and not self.is_it_urgent:
            # print(f"\n\n{item.get('Number 1 Type', '')} Skipped")
            self.other_phone_type_items.append(item)
            return

        self.write_item_into_csv_file(item)
        self.item_scraped_counter += 1

        if self.item_scraped_counter >= self.items_count_to_scrape:
            raise CloseSpider('Required Item Count Reached.')

        yield item

    def get_person_item(self, response, owner_num):
        first_name, last_name = self.get_first_and_last_Name(response)
        person_emails = self.get_emails(response)

        owner = f'Owner {owner_num}'
        person_item = dict()
        person_item[f'{owner} First Name'] = first_name
        person_item[f'{owner} Last Name'] = last_name
        person_item.update(self.get_phone_items(response))

        for index in range(5):
            person_item[f'Email {index + 1}'] = ''

        for index, email in enumerate(person_emails[:5]):
            person_item[f'Email {index + 1}'] = email

        return person_item

    def get_item_input_fields(self, input_row):
        input_item = input_row
        input_item['Address'] = input_row.get('Street') or input_row.get('Address')
        input_item['Mailing Address'] = input_row.get('Owner Mailing Address')
        input_item['Mailing City'] = input_row.get('Owner Mailing City')
        input_item['Mailing State'] = input_row.get('Owner Mailing State')
        input_item['Mailing Zip'] = input_row.get('Owner Mailing Zip')

        return input_item

    def get_phone_items(self, response):
        phones_selector = response.xpath('//span[@class="phones-label section-label"]/parent::h2').xpath(
            'following-sibling::h3')
        phone_numbers = [phone.css('a.phone ::text').get() for phone in phones_selector][:3]
        phone_types = [x.xpath('following-sibling::p/span[@class="d-block phone-type"]/text()').get('').strip() for x in
                       phones_selector][:3]
        phones_last_reported = [x.xpath('following-sibling::p/small/span/text()').re_first(r'in (.*)') for x in
                                phones_selector][:3]

        phone_item = dict()

        for index, (number, p_type, last_reported) in enumerate(zip(phone_numbers, phone_types, phones_last_reported)):
            phone_item[f'Number {index + 1}'] = number
            phone_item[f'Number {index + 1} Type'] = p_type
            phone_item[f'Number {index + 1} Status'] = last_reported

        return phone_item

    def is_person_matched(self, input_row, web_person_row, owner, persons_json):
        input_fname = input_row.get(f'Owner {owner} First Name').lower().strip()
        input_lname = input_row.get(f'Owner {owner} Last Name').lower().strip()

        if not input_fname or not input_lname:
            return False

        name = web_person_row.css('.name-given ::text').get('').strip()

        if not name:
            return False

        found_name = self.get_name_parts(name)

        if not found_name:
            return False

        found_fname = found_name.get('first_name', '').lower()
        found_lname = found_name.get('last_name', '').lower()

        first_name_matched = input_fname == found_fname or input_fname in found_fname or found_fname in input_fname
        last_name_matched = input_lname == found_lname or input_lname in found_lname or found_lname in input_lname

        if first_name_matched and last_name_matched:
            return True

        # To match the name even if first and last names are interchanged. Sometimes, the first and last names on website are in last and first pattern
        name = name.lower()
        if input_fname in name and input_lname in name:
            return True

        # Check First and Last names in other names to see if there is a match
        other_names = persons_json.get(name, {}).get('additionalName', [])
        if other_names:
            for other_name in other_names:
                other_name = other_name.lower()
                if input_fname in other_name and input_lname in other_name:
                    return True

        return False

    def get_name_parts(self, name):
        try:
            name_parts = HumanName(name)
            # punctuation_re = re.compile(r'[^\w-]')
            return {
                'first_name': name_parts.first,
                'last_name': name_parts.last,
            }
        except TypeError:
            return {
                'first_name': '',
                'last_name': ''
            }

    def get_first_and_last_Name(self, response):
        first_name = response.css('#SearchCriteriaViewModel_FirstName::attr(value)').get('')
        # middle_name = response.css('#SearchCriteriaViewModel_MiddleName::attr(value)').get('')
        last_name = response.css('#SearchCriteriaViewModel_LastName::attr(value)').get('')
        return first_name, last_name

    def get_street_address_key(self, address_obj):
        return f"{address_obj.get('AddressNumber', '')} {address_obj.get('StreetName', '')}".strip()

    def get_emails(self, response):
        try:
            person_json = json.loads(response.css('script:contains("Person")::text').get('').strip())[0]
        except json.JSONDecodeError:
            return []
        except Exception:
            return []

        emails = person_json.get('email', []) or []

        return [emails] if isinstance(emails, str) else emails

    def get_contact_item(self, contacts, contact_type):
        contact_item = dict()

        if isinstance(contacts, str):
            contact_item[f'{contact_type}_1'] = contacts

        if isinstance(contacts, list):
            for index, value in enumerate(contacts):
                contact_item[f'{contact_type}_{index + 1}'] = value

        return contact_item

    def write_item_into_csv_file(self, item):
        with self.multiprocessing_file_lock:  # To handle if this file could be accessed with multiple threads at the same time
            with open(self.output_filename, mode='a', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)

                # File is created inside the main.py module so no need check for headers in these 2 lines
                # if csvfile.tell() == 0:
                #     writer.writerow(self.output_csv_fieldnames)

                writer.writerow([item.get(col) for col in self.csv_mapped_item_fieldnames])

    def get_item_fields_names(self):
        # These columns are the item fields inside this spider

        return [
            'Address', 'City', 'State', 'Zip', 'Mailing Address', 'Mailing City', 'Mailing State',
            'Mailing Zip',

            'Owner 1 First Name', 'Owner 1 Last Name',

            'Number 1', 'Number 1 Type', 'Number 1 Status',
            'Number 2', 'Number 2 Type', 'Number 2 Status',
            'Number 3', 'Number 3 Type', 'Number 3 Status',

            'Email 1', 'Email 2', 'Email 3', 'Email 4', 'Email 5',
        ]

    def add_other_type_phone_item_into_csv(self):
        required_items = self.items_count_to_scrape - self.item_scraped_counter

        for item in self.other_phone_type_items[:required_items]:
            self.write_item_into_csv_file(item)

    def close(spider, reason):
        if spider.item_scraped_counter < spider.items_count_to_scrape:
            spider.add_other_type_phone_item_into_csv()

        print(f'\n\n\nScript Started at: {spider.script_started_at}')
        print(f'Script finished at: {datetime.now().strftime("%I:%M:%S %p")}')
